package com.lqw.algorithm.recursion;

import java.util.HashMap;

/**
 * @author linqiwen
 */
public class SolutionSix {

    private int preorderIdx;
    private int[] preorder;
    private HashMap<Integer, Integer> inorderIdxMap;

    public TreeNode buildTree(int[] preorder, int[] inorder) {

        preorderIdx = 0;
        this.preorder = preorder;

        int inorderLeft = 0;
        int inorderRight = inorder.length;

        inorderIdxMap = new HashMap<>();
        for (int i = 0; i < inorder.length; i++) {
            inorderIdxMap.put(inorder[i], i);
        }

        return reverseBuildTree(inorderLeft, inorderRight);

    }

    private TreeNode reverseBuildTree(int inorderLeft, int inorderRight) {
        //terminator终止条件
        if (inorderLeft == inorderRight) {
            return null;
        }

        //处理当前逻辑
        TreeNode rootTreeNode = new TreeNode(preorder[preorderIdx++]);
        int rootInorderIndex = inorderIdxMap.get(rootTreeNode.val);

        //下探到下一层
        rootTreeNode.left = reverseBuildTree(inorderLeft, rootInorderIndex);
        rootTreeNode.right = reverseBuildTree(rootInorderIndex + 1, inorderRight);

        //清理当前层
        return rootTreeNode;
    }

    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }

    public static void main(String[] args) {
        SolutionSix solutionSix = new SolutionSix();
        int[] preorder = new int[]{3,9,20,15,7};
        int[] inorder = new int[]{9,3,15,20,7};
        solutionSix.buildTree(preorder, inorder);
    }
}
