package com.lqw.algorithm.recursion;

/**
 * 最近重复子问题
 * <p>
 * 一、终止条件
 * 二、process （split bit ）
 * <p>
 * <p>
 * Pow（x，n）
 * subProblem：Pow（x，n/2）
 * <p>
 * odd Pow（x，n） = pow（x，n/2） * pow（x，n/2）* x
 * even Pow（x，n） = pow（x，n/2） * pow（x，n/2）
 *
 * @author linqiwen
 */
public class SolutionTwelve {

    public double myPow(double x, int n) {

        if (x == 0) {
            return 0;
        }

        long loopNum = n;
        if (n < 0) {
            x = 1 / x;
            loopNum = -n;
        }

        return fastPow(x, loopNum);
    }

    private double fastPow(double x, long n) {
        //terminator 终止条件
        if (n == 0) {
            return 1;
        }

        //下探到下一层
        double half = fastPow(x, n / 2);
        double result;

        //process 处理逻辑
        if (n % 2 == 0) {
            result = half * half;
        } else {
            result = half * half * x;
        }

        //reverse current state
        return result;
    }

    public static void main(String[] args) {
        SolutionTwelve solutionTwelve = new SolutionTwelve();
        System.out.println(solutionTwelve.myPow(2, 10));
    }
}