package com.lqw.algorithm.binaryheap;

/**
 * 堆
 *
 * @author linqiwen
 */
public class Heap {

    /**
     * 堆能存储大小
     */
    private int size;

    /**
     * 存储数据数组，从下标1开始存储数据
     */
    private int[] datas;

    /**
     * 目前堆中的数据，容量
     */
    private int count;

    /**
     * 大项堆，小项堆
     * true 大项堆
     */
    private boolean typeFlag;

    public Heap(int capacity) {
        this(capacity, false);
    }

    public Heap(int capacity, boolean typeFlag) {
        this.size = capacity;
        count = 0;
        datas = new int[capacity + 1];
        this.typeFlag = typeFlag;
    }

    /**
     * 插入
     */
    public boolean insert(int data, int capacity) {
        return true;
    }

    /**
     * 删除
     */
    public boolean remove() {
        return true;
    }

    /**
     * 堆化
     */
    public void heapify() {

    }

    /**
     * 交换数据
     */
}
