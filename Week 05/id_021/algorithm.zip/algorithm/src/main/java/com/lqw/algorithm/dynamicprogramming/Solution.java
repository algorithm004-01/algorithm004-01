package com.lqw.algorithm.dynamicprogramming;

/**
 *
 * 一个机器人位于一个 m x n 网格的左上角 （起始点在下图中标记为“Start” ）。
 *
 * 机器人每次只能向下或者向右移动一步。机器人试图达到网格的右下角（在下图中标记为“Finish”）。
 *
 * 问总共有多少条不同的路径？
 *
 * 图片
 * @see /resources/robot_maze.png
 *
 * 例如，上图是一个7 x 3 的网格。有多少可能的路径？
 *
 * 说明：m 和 n 的值均不超过 100。
 *
 * 示例 1:
 *
 * 输入: m = 3, n = 2
 * 输出: 3
 * 解释:
 * 从左上角开始，总共有 3 条路径可以到达右下角。
 * 1. 向右 -> 向右 -> 向下
 * 2. 向右 -> 向下 -> 向右
 * 3. 向下 -> 向右 -> 向右
 * 示例 2:
 *
 * 输入: m = 7, n = 3
 * 输出: 28
 *
 * 链接：https://leetcode-cn.com/problems/unique-paths
 *
 *
 *
 * 解题思路
 * 1、最后一列和最后一行都为1
 * 2、最优子结构
 * 3、存储中间状态
 * 4、DP方程 f(nums[i][j]) = f(nums[i+1][j]) + f(nums[i][j+1])
 *
 * @see SolutionOne
 *
 * @author linqiwen
 */
public class Solution {

    //m是列，n是行
    public int uniquePaths(int m, int n) {
        if (m < 1 || m > 100 || n < 1 || n > 100) {
            return 0;
        }
        //存储中间状态
        int[][] nums = new int[n][m];
        //最后一行都为1
        for (int i = 0; i < m;i++) {
            nums[n-1][i] = 1;
        }

        //最后一列都为1
        for (int i = 0;i < n;i++) {
            nums[i][m-1] = 1;
        }

        for (int i = n - 2; i >= 0;i--) {
            for (int j = m - 2;j >= 0;j--) {
                nums[i][j] = nums[i+1][j] + nums[i][j+1];
            }
        }

        return nums[0][0];

    }

}
