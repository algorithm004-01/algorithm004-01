package com.lqw.algorithm.dynamicprogramming;

import java.util.List;

/**
 * 给定一个三角形，找出自顶向下的最小路径和。每一步只能移动到下一行中相邻的结点上。
 * <p>
 * 例如，给定三角形：
 * <p>
 * [
 * [2],
 * [3,4],
 * [6,5,7],
 * [4,1,8,3]
 * ]
 * 自顶向下的最小路径和为 11（即，2 + 3 + 5 + 1 = 11）。
 * <p>
 * 说明：
 * <p>
 * 如果你可以只使用 O(n) 的额外空间（n 为三角形的总行数）来解决这个问题，那么你的算法会很加分。
 * <p>
 * 链接：https://leetcode-cn.com/problems/triangle
 * <p>
 * 解题思路：
 * 重复性：problem(i,j) = min(sub(i+1,j) + sub(i+1, j+1)) + f[i, j]
 * 定义状态数组：f[i, j]
 * DP方程：f[i,j] = min(f[i+1,j], f[i+1,j+1]) + f[i, j]
 * <p>
 * 时间复杂度O(n*m)
 *
 * @see SolutionThree
 * @see SolutionFour
 *
 * @author linqiwen
 */
public class SolutionTwo {

    public int minimumTotal(List<List<Integer>> triangle) {

        int[] array = new int[triangle.get(triangle.size() - 1).size() + 1];

        for (int i = triangle.size() - 1; i >= 0; i--) {

            for (int j = 0; j < triangle.get(i).size(); j++) {
                array[j] = Math.min(array[j], array[j + 1]) + triangle.get(i).get(j);
            }

        }


        return array[0];
    }

}
