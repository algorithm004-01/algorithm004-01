package com.lqw.algorithm.cache;

/**
 * 最不经常使用
 *
 * @author linqiwen
 */
public class LFUCache {

    public LFUCache(int capacity) {

    }

    public int get(int key) {
        return -1;
    }

    public void put(int key, int value) {

    }

}





















