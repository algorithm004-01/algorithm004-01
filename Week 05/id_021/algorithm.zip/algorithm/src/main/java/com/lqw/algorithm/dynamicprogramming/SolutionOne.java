package com.lqw.algorithm.dynamicprogramming;

import java.util.Arrays;

/**
 * 时间复杂度o（n*m），空间复杂度o（n）
 * <p>
 * 解题思路：
 * 1、最后一行的所有元素都为1，最后一列的所有元素都为1
 * 2、使用一维数组，存储每一行所有的列元素
 * everyCurNums[j] += everyCurNums[j-1];
 *
 * @author linqiwen
 */
public class SolutionOne {

    //m是列，n是行
    public int uniquePaths(int m, int n) {

        int[] everyCurNums = new int[m];

        Arrays.fill(everyCurNums, 1);

        for (int i = 1; i < n; i++) {
            for (int j = 1; j < m; j++) {
                everyCurNums[j] += everyCurNums[j - 1];
            }
        }
        return everyCurNums[m - 1];
    }

}
