package com.lqw.algorithm.tree;

/**
 * @author linqiwen
 */
public class SolutionOne {

    public boolean isValidBST(TreeNode root) {
        return isValidBST(root, true, Long.MAX_VALUE);
    }

    private boolean isValidBST(TreeNode root, boolean lessThan, long parentValue) {

        //终止条件
        if (root == null) {
            return true;
        }

        //处理逻辑
        if ((lessThan && root.val >= parentValue) || (!lessThan && root.val <= parentValue)) {
            return false;
        }
        //下沉
        return isValidBST(root.left, true, root.val) && isValidBST(root.right, false, root.val);
    }

    public static class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }
}
