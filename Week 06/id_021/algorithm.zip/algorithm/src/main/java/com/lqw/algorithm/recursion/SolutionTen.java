package com.lqw.algorithm.recursion;

import java.util.List;

/**
 * @author linqiwen
 */
public class SolutionTen {

    public List<List<Integer>> combine(int n, int k) {

        return null;

    }

}
