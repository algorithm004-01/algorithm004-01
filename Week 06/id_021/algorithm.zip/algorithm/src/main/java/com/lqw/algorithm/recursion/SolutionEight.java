package com.lqw.algorithm.recursion;

import java.util.HashMap;

/**
 * 根据一棵树的中序遍历与后序遍历构造二叉树。
 * <p>
 * 注意:
 * 你可以假设树中没有重复的元素。
 * <p>
 * 例如，给出
 * <p>
 * 中序遍历 inorder = [9,3,15,20,7]
 * 后序遍历 postorder = [9,15,7,20,3]
 * 返回如下的二叉树：
 * <p>
 * 3
 * / \
 * 9  20
 * /  \
 * 15   7
 * <p>
 * 链接：https://leetcode-cn.com/problems/construct-binary-tree-from-inorder-and-postorder-traversal
 *
 * @author linqiwen
 */
public class SolutionEight {

    public TreeNode buildTree(int[] inorder, int[] postorder) {

        if (inorder == null || postorder == null) {
            return null;
        }

        HashMap<Integer, Integer> inorderIndexMap = new HashMap<>();
        for (int i = 0; i < inorder.length; i++) {
            inorderIndexMap.put(inorder[i], i);
        }

        return reverseBuildTree(inorder, 0, inorder.length, postorder, 0, inorder.length, inorderIndexMap);
    }

    private TreeNode reverseBuildTree(int[] inorder, int inorderLeft, int inorderRight, int[] postorder, int postorderLeft, int postorderRight, HashMap<Integer, Integer> inorderIndexMap) {

        //terminator终结条件
        if (inorderLeft == inorderRight) {
            return null;
        }

        //处理逻辑
        TreeNode rootTreeNode = new TreeNode(postorder[postorderRight - 1]);
        int rootTreeNodeIndex = inorderIndexMap.get(rootTreeNode.val);

        //下探到下一层
        //左子树
        rootTreeNode.left = reverseBuildTree(inorder, inorderLeft, rootTreeNodeIndex, postorder, postorderLeft, postorderLeft + rootTreeNodeIndex - inorderLeft, inorderIndexMap);

        //右子树
        rootTreeNode.right = reverseBuildTree(inorder, rootTreeNodeIndex + 1, inorderRight, postorder, postorderLeft + rootTreeNodeIndex - inorderLeft, postorderRight - 1, inorderIndexMap);

        //处理当前层
        return rootTreeNode;

    }

    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }

    public static void main(String[] args) {

        SolutionEight solutionEight = new SolutionEight();
        int[] inorder = new int[]{9,3,15,20,7};
        int[] postorder = new int[]{9,15,7,20,3};
        solutionEight.buildTree(inorder, postorder);

    }

}
