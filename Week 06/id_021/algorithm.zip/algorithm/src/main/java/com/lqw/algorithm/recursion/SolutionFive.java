package com.lqw.algorithm.recursion;

import javax.xml.bind.SchemaOutputResolver;
import java.util.Arrays;
import java.util.HashMap;

/**
 * @author linqiwen
 */
public class SolutionFive {

    public TreeNode buildTree(int[] preorder, int[] inorder) {
        HashMap<Integer, Integer> inorderElementIndexMap = new HashMap<>(inorder.length);
        for (int i = 0; i < inorder.length; i++) {
            inorderElementIndexMap.put(inorder[i], i);
        }

        return recurTree(preorder, inorder, inorderElementIndexMap);

    }

    private TreeNode recurTree(int[] preorder, int[] inorder, HashMap<Integer, Integer> inorderElementIndexMap) {

        //terminator终结者
        if (preorder == null || preorder.length == 0 || inorder == null || inorder.length == 0) {
            return null;
        }

        //处理当前逻辑
        TreeNode rootNode = new TreeNode(preorder[0]);
        System.out.println(rootNode.val);
        int rootNodeInOrderIndex = inorderElementIndexMap.get(rootNode.val);



        int[] leftPreorde = Arrays.copyOfRange(preorder, 1, rootNodeInOrderIndex + 1);
        int[] leftInOrder = Arrays.copyOfRange(inorder, 0, rootNodeInOrderIndex);
        int[] rightPreorde = Arrays.copyOfRange(preorder, rootNodeInOrderIndex + 1, preorder.length);
        int[] rightInOrder = Arrays.copyOfRange(inorder, rootNodeInOrderIndex + 1, inorder.length);



        //下探到下一层
        //构建左子树
        rootNode.left = recurTree(leftPreorde, leftInOrder, inorderElementIndexMap);

        //构建右子树
        rootNode.right = recurTree(rightPreorde, rightInOrder, inorderElementIndexMap);

        //清理当前层
        return rootNode;
    }

    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }

    public static void main(String[] args) {
        SolutionFive solutionFive = new SolutionFive();
        int[] preorder = new int[]{3,9,20,15,7};
        int[] inorder = new int[]{9,3,15,20,7};
        solutionFive.buildTree(preorder, inorder);
    }
}
