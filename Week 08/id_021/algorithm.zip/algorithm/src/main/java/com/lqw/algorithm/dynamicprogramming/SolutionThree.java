package com.lqw.algorithm.dynamicprogramming;

import java.util.List;

/**
 * 解题思路
 * 1、递归,自顶向下
 *
 * @author linqiwen
 */
public class SolutionThree {

    public int minimumTotal(List<List<Integer>> triangle) {

        return recursive(0, 0, triangle);
    }

    private int recursive(int level, int currentElementIndex, List<List<Integer>> triangle) {

        //终止条件
        if (level == triangle.size()) {
            return 0;
        }

        //处理当前层
        int currentValue = triangle.get(level).get(currentElementIndex);

        //下探到下一层
        int nextLevelElementValue = recursive(level + 1, currentElementIndex, triangle);

        int nextLevelElementNextValue = recursive(level + 1, currentElementIndex + 1, triangle);

        currentValue += Math.min(nextLevelElementValue, nextLevelElementNextValue);

        //清理当前层

        return currentValue;
    }

}
