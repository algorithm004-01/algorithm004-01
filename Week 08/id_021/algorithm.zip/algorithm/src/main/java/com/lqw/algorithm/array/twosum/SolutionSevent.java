package com.lqw.algorithm.array.twosum;

/**
 * BST查找元素，时间复杂度nlog(n)
 *
 * @author linqiwen
 */
public class SolutionSevent {

    public boolean findTarget(TreeNode root, int k) {
        return findTarget(root, root, k);
    }

    private boolean findTarget(TreeNode node, TreeNode root, int k) {

        if (node == null) {
            return false;
        }

        int matchVal = k - node.val;

        TreeNode matchTreeNode = findTreeNode(root, matchVal);

        if (matchTreeNode != null && !matchTreeNode.equals(node)) {
            return true;
        }

        return findTarget(node.left, root, k) || findTarget(node.right, root, k);

    }

    private TreeNode findTreeNode (TreeNode root, int matchVal) {

        if (root == null) {
            return null;
        }

        if (root.val == matchVal) {
            return root;
        } else if (root.val > matchVal) {
            return findTreeNode(root.left, matchVal);
        } else {
            return findTreeNode(root.right, matchVal);
        }

    }

    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }
}
