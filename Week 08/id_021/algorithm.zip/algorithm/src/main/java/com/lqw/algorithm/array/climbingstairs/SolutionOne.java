package com.lqw.algorithm.array.climbingstairs;

import java.util.Arrays;

/**
 * 爬楼梯
 */
public class SolutionOne {

    public static void main(String[] args) {
        int[] nums = new int[]{2,3,4,0};
        System.out.println(Arrays.toString(nums));

    }

}
