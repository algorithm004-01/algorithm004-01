package com.lqw.algorithm.recursion;

/**
 * 输入: 2.00000, 10
 * 输出: 1024.00000
 * 示例 2:
 * <p>
 * 输入: 2.10000, 3
 * 输出: 9.26100
 * 示例 3:
 * <p>
 * 输入: 2.00000, -2
 * 输出: 0.25000
 * 解释: 2-2 = 1/22 = 1/4 = 0.25
 * 说明:
 * <p>
 * -100.0 < x < 100.0
 * n 是 32 位有符号整数，其数值范围是 [−231, 231 − 1] 。
 * <p>
 * 链接：https://leetcode-cn.com/problems/powx-n
 * <p>
 * 解题思路
 * 1、暴力破解 x for循环n次
 * 2、快速幂算法，递归
 * 3、快速幂算法，循环
 * 注意事项：
 * 1、x等于0
 * 2、n等于0
 * 3、n小于0
 *
 * @author linqiwen
 * @see SolutionTwelve
 */
class SolutionEleven {

    public double myPow(double x, int n) {
        double res = 1.0;

        for (int i = n; i != 0; i /= 2) {
            x *= x;
        }
        return n < 0 ? 1 / res : res;
    }

    public static void main(String[] args) {
        SolutionEleven solutionEleven = new SolutionEleven();
        System.out.println(solutionEleven.myPow(2, 10));
    }
}
