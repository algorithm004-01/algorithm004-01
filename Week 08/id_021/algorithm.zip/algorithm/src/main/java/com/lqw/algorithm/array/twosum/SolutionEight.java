package com.lqw.algorithm.array.twosum;

import java.util.HashSet;

/**
 * 使用hashSet
 *
 * @author linqiwen
 */
public class SolutionEight {

    public boolean findTarget(TreeNode root, int k) {
        return find(root, new HashSet<>(), k);
    }

    private boolean find(TreeNode root, HashSet<Integer> treeNodeElementSet, int k) {

        //终止条件
        if (root == null) {
            return false;
        }

        //处理逻辑
        if (treeNodeElementSet.contains(k - root.val)) {
            return true;
        }

        treeNodeElementSet.add(root.val);

        return find(root.left, treeNodeElementSet, k) || find(root.right, treeNodeElementSet, k);

    }


    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }
}
