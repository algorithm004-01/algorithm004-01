package com.lqw.algorithm.dynamicprogramming;

import java.util.List;

/**
 * SolutionThree基础上加缓存
 *
 * @author linqiwen
 */
public class SolutionFour {

    public int minimumTotal(List<List<Integer>> triangle) {

        int row = triangle.size();

        Integer[][] memo = new Integer[row][row];
        return recursive(0, 0, triangle, memo);
    }

    private int recursive(int level, int currentElementIndex, List<List<Integer>> triangle, Integer[][] memo) {

        //终止条件
        if (level == triangle.size()) {
            return 0;
        }

        if (memo[level][currentElementIndex] != null) {
            return memo[level][currentElementIndex];
        }

        //处理当前层
        int currentValue = triangle.get(level).get(currentElementIndex);

        //下探到下一层
        int nextLevelElementValue = recursive(level + 1, currentElementIndex, triangle, memo);

        int nextLevelElementNextValue = recursive(level + 1, currentElementIndex + 1, triangle, memo);

        currentValue += Math.min(nextLevelElementValue, nextLevelElementNextValue);

        memo[level][currentElementIndex] = currentValue;

        //清理当前层

        return currentValue;
    }

}
