package com.lqw.algorithm.array.threesum;

import java.util.*;

/**
 * @author linqiwen
 */
public class SolutionTwo {

    public List<List<Integer>> threeSum(int[] nums) {

        List<List<Integer>> result = new ArrayList<>();

        int length;

        if (nums == null || (length = nums.length) < 3) {
            return result;
        }

        Map<Integer, List<Integer>> matchValueAndIndexsMap = new HashMap<>();

        Arrays.sort(nums);

        for (int i = 0; i < length - 1; i++) {

            if (i > 0 && nums[i] == nums[i - 1]) {
                continue;
            }
            int j = i + 1;
            while (j < length) {
                matchValueAndIndexsMap.put(-(nums[i] + nums[j]), Arrays.asList(i, j));
                j++;
                while (j < length && nums[j] == nums[j - 1]) {
                    j++;
                }
            }

        }

        System.out.println(matchValueAndIndexsMap);


        for (int i = 0; i < length; i++) {

            if (i > 0 && nums[i] == nums[i - 1]) {
                continue;
            }

            List<Integer> matchIndexList = matchValueAndIndexsMap.get(nums[i]);
            if (matchIndexList != null && !matchIndexList.contains(i)) {
                result.add(Arrays.asList(nums[i], nums[matchIndexList.get(0)], nums[matchIndexList.get(1)]));
            }
        }

        return result;

    }

}
