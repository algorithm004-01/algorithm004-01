package com.lqw.algorithm.cache;

/**
 * 先进先出
 *
 * @author linqiwen
 */
public class FIFOCache {



}
