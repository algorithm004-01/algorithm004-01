package com.lqw.algorithm.bit;

/**
 * 解题思路
 * X=X&(X-1)清零最低位的1
 *
 * @author linqiwen
 */
public class SolutionTwo {

    public int hammingWeight(int n) {

        int bits = 0;

        while (n != 0) {

            bits++;
            n &= n-1;
        }
        return bits;
    }

}