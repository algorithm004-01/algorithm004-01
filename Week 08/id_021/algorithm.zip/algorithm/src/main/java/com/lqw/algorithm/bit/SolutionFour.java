package com.lqw.algorithm.bit;

/**
 * @author linqiwen
 */
public class SolutionFour {

    public int hammingWeight(int n) {
        return Integer.bitCount(n);
    }

}
