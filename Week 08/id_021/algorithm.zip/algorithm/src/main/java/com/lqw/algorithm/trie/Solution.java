package com.lqw.algorithm.trie;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author linqiwen
 */
public class Solution {

    public List<String> findWords(char[][] board, String[] words) {

        //建字典树
        WordTrie wordTrie = new WordTrie();
        for (String word : words) {
            wordTrie.insert(word);
        }

        TrieNode root = wordTrie.root;

        //单词去重
        Set<String> result = new HashSet<>();

        //DFS遍历二维数组
        int m = board.length;
        int n = board[0].length;

        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                helper(i, j, m, n, root, board, result);
            }
        }

        return new ArrayList<>(result);
    }

    private void helper(int i, int j, int m, int n, TrieNode root, char[][] board, Set<String> result) {

        //终止条件
        if (i < 0 || i >= m || j < 0 || j > n || board[i][j] == '@') {
            return;
        }

        char temp = board[i][j];

        TrieNode node = root.get(temp);

        //处理当前逻辑
        if (node == null) {
            return;
        }
        board[i][j] = '@';
        if (node.isEnd()) {
            result.add(node.getVal());
        }

        //下探到下一层，四联通
        //上
        helper(i - 1, j, m, n, node, board, result);
        //下
        helper(i + 1, j, m, n, node, board, result);
        //左
        helper(i, j - 1, m, n, node, board, result);
        //右
        helper(i, j + 1, m, n, node, board, result);

        //清理当前状态
        board[i][j] = temp;
    }


    class WordTrie {

        private TrieNode root;

        WordTrie() {
            root = new TrieNode();
        }

        private void insert(String word) {

            TrieNode node = root;

            for (int i = 0; i < word.length(); i++) {

                char character = word.charAt(i);
                if (!node.containsKey(character)) {
                    node.put(character);
                }
                node = node.get(character);
            }
            node.setEnd();
            node.setVal(word);
        }

    }

    class TrieNode {

        private final TrieNode[] links;

        private static final int FORK_NUM = 26;

        private boolean isEnd;

        private String val;

        TrieNode() {
            this.links = new TrieNode[FORK_NUM];
        }

        TrieNode get(char character) {

            return links[character - 'a'];

        }

        public void put(char character) {

            links[character - 'a'] = new TrieNode();

        }

        boolean containsKey(char character) {
            return links[character - 'a'] != null;
        }

        boolean isEnd() {
            return isEnd;
        }

        void setEnd() {
            isEnd = true;
        }

        public String getVal() {
            return val;
        }

        public void setVal(String val) {
            this.val = val;
        }
    }

}
