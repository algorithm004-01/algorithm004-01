package com.lqw.algorithm.bfsanddfs;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 广度优先搜索
 *
 * @author linqiwen
 */
public class SolutionTwo {

    public List<List<Integer>> levelOrder(TreeNode root) {

        List<List<Integer>> levelNodeList = new ArrayList<>();

        if (root == null) {
            return levelNodeList;
        }

        LinkedList<TreeNode> queue = new LinkedList<>();

        queue.add(root);

        int level = 0;

        while (!queue.isEmpty()) {

            levelNodeList.add(new ArrayList<>());

            int size = queue.size();
            for (int i = 0; i < size; i++) {
                TreeNode node = queue.remove();
                levelNodeList.get(level).add(node.val);

                if (node.left != null) {
                    queue.add(node.left);
                }
                if (node.right != null) {
                    queue.add(node.right);
                }

            }
            level++;
        }

        return levelNodeList;
    }

    public class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }
}
