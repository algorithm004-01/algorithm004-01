package com.lqw.algorithm.bit;

/**
 * @author linqiwen
 */
public class SolutionSeven {

    public boolean isPowerOfTwo(int n) {
        if (n <= 0) {
            return false;
        }

        while (n > 0) {

            if ((n & 1) == 1 ) {
                if (n == 1) {
                    return true;
                }
                return false;
            }
            n >>= 1;
        }

        return true;

    }

    public static void main(String[] args) {

        SolutionSeven solutionSeven = new SolutionSeven();
        solutionSeven.isPowerOfTwo(6);

    }

}
