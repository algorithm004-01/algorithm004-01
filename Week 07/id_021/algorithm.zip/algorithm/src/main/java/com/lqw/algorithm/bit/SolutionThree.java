package com.lqw.algorithm.bit;

/**
 * 取模
 *
 * @author linqiwen
 */
public class SolutionThree {

    public int hammingWeight(int n) {

        int bits = 0;

        while (n > 0) {

            if ((n & 1) == 1) {
                bits++;
            }
            n >>>= 1;
        }
        return bits;
    }

}
