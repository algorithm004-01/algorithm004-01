package com.lqw.algorithm.array.twosum;

import java.util.Arrays;

/**
 * 解题思路两边夹逼法
 *
 * @author linqiwen
 */
public class SolutionFive {

    public int[] twoSum(int[] nums, int target) {

        if (nums == null) {
            return new int[]{};
        }

        int low = 0;
        int high = nums.length - 1;

        while (low <= high) {

            if (nums[low] + nums[high] == target) {
                return new int[] {low + 1, high + 1};
            } else if (nums[low] + nums[high] < target) {
                low++;
            } else {
                high--;
            }

        }
        return new int[]{};
    }

}
