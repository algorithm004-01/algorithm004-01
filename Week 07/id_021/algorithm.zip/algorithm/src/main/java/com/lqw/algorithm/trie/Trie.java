package com.lqw.algorithm.trie;

/**
 * 实现一个 Trie (前缀树)，包含 insert, search, 和 startsWith 这三个操作。
 *
 * 示例:
 *
 * Trie trie = new Trie();
 *
 * trie.insert("apple");
 * trie.search("apple");   // 返回 true
 * trie.search("app");     // 返回 false
 * trie.startsWith("app"); // 返回 true
 * trie.insert("app");
 * trie.search("app");     // 返回 true
 * 说明:
 *
 * 你可以假设所有的输入都是由小写字母 a-z 构成的。
 * 保证所有输入均为非空字符串。
 *
 * 链接：https://leetcode-cn.com/problems/implement-trie-prefix-tree
 *
 * 字典树
 *
 * @author linqiwen
 */
public class Trie {

    private TrieNode trieRoot;

    public Trie() {
        this.trieRoot = new TrieNode();
    }

    public void insert(String word) {
        TrieNode node = trieRoot;
        for (int i = 0; i < word.length(); i++) {
            char character = word.charAt(i);
            if (!node.containsKey(character)) {
                node.put(character);
            }
            node = node.get(character);
        }
        node.setEnd();
    }

    public boolean search(String word) {
        TrieNode node = searchPrefix(word);
        return node != null && node.isEnd();
    }

    public boolean startWith(String prefix) {
        TrieNode node = searchPrefix(prefix);
        return node != null;
    }

    private TrieNode searchPrefix(String word) {
        TrieNode node = trieRoot;

        for (int i = 0; i < word.length(); i++) {
            char character = word.charAt(i);
            if (!node.containsKey(character)) {
                return null;
            }
            node = node.get(character);
        }
        return node;
    }

    class TrieNode {

        private final TrieNode[] links;

        private static final int FORK_NUM = 26;

        private boolean isEnd;

        TrieNode() {
            this.links = new TrieNode[FORK_NUM];
        }

        public TrieNode get(char character) {

            return links[character - 'a'];

        }

        public void put(char character) {

            links[character - 'a'] = new TrieNode();

        }

        public boolean containsKey(char character) {
            return links[character - 'a'] != null;
        }

        public boolean isEnd() {
            return isEnd;
        }

        public void setEnd() {
            isEnd = true;
        }

    }

}
