package com.lqw.algorithm.array.twosum;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 给定一个二叉搜索树和一个目标结果，如果 BST 中存在两个元素且它们的和等于给定的目标结果，则返回 true。
 * <p>
 * 案例 1:
 * <p>
 * 输入:
 * 5
 * / \
 * 3   6
 * / \   \
 * 2   4   7
 * <p>
 * Target = 9
 * <p>
 * 输出: True
 *  
 * <p>
 * 案例 2:
 * <p>
 * 输入:
 * 5
 * / \
 * 3   6
 * / \   \
 * 2   4   7
 * <p>
 * Target = 28
 * <p>
 * 输出: False
 * <p>
 * 链接：https://leetcode-cn.com/problems/two-sum-iv-input-is-a-bst
 * <p>
 * 解题思路
 * 1、中序遍历
 * 2、夹逼法
 *
 * @see SolutionSevent BST查找元素
 * @see SolutionEight hashSet
 *
 * @author linqiwen
 */
public class SolutionSix {

    public boolean findTarget(TreeNode root, int k) {
        List<Integer> treeElementValueArray = new ArrayList<>();

        //递归中序遍历，升序
        treeElementValueToArray(root, treeElementValueArray);

        int size = treeElementValueArray.size();

        //夹逼法
        int low = 0;
        int high = size - 1;

        /*while (low < high) {
            int sum = treeElementValueArray.get(low) + treeElementValueArray.get(high);
            if (sum == k) {
                return true;
            } else if (sum > k) {
                high--;
            } else {
                low++;
            }
        }*/

        for (int i = 0, j = size - 1, sum = 0; i < j;) {

            sum = treeElementValueArray.get(i) + treeElementValueArray.get(j);

            if (sum == k) {
                return true;
            } else if (sum > k) {
                j--;
            } else {
                i++;
            }

        }


        return false;
    }

    private void treeElementValueToArray(TreeNode root, List<Integer> treeElementValueArray) {

        //终止条件
        if (root == null) {
            return;
        }

        //左子树
        treeElementValueToArray(root.left, treeElementValueArray);

        treeElementValueArray.add(root.val);

        //右子树
        treeElementValueToArray(root.right, treeElementValueArray);

    }

    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }


}
