package com.lqw.algorithm.array.twosum;

import java.util.HashMap;
import java.util.HashSet;

/**
 * @author linqiwen
 */
public class SolutionNine {

    public boolean findTarget(TreeNode root, int k) {
        return find(root, new HashMap<>(), k);
    }

    private boolean find(TreeNode root, HashMap<Integer,Integer> treeNodeElementMap, int k) {

        if (root == null) {
            return false;
        }

        if (treeNodeElementMap.get(k - root.val) != null) {
            return true;
        }

        treeNodeElementMap.put(root.val, root.val);

        return find(root.left, treeNodeElementMap, k) || find(root.right, treeNodeElementMap, k);

    }


    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }
}
