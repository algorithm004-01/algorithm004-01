package com.lqw.algorithm.recursion;

import java.util.HashMap;

/**
 * @author linqiwen
 */
public class SolutionSevent {

    public TreeNode buildTree(int[] preorder, int[] inorder) {

        if (preorder ==  null || inorder == null) {
            return null;
        }

        HashMap<Integer, Integer> inorderIdxMap = new HashMap<>();
        for (int i = 0; i < inorder.length; i++) {
            inorderIdxMap.put(inorder[i], i);
        }

        return reverseBuildTree(preorder, 0, preorder.length, inorder, 0, preorder.length, inorderIdxMap);

    }

    private TreeNode reverseBuildTree(int[] preorder, int preorderLeft, int preorderRight, int[] inorder, int inorderLeft, int inorderRight, HashMap<Integer,Integer> inorderIdxMap) {

        //terminator 终结者
        if (inorderLeft == inorderRight) {
            return null;
        }

        //process 处理逻辑
        System.out.println(preorder[preorderLeft]);
        TreeNode rootTreeNode = new TreeNode(preorder[preorderLeft]);
        int rootTreeNodeInorderIndex = inorderIdxMap.get(rootTreeNode.val);

        //下探到下一层
        //左子树
        rootTreeNode.left = reverseBuildTree(preorder, preorderLeft + 1,  preorderLeft + 1 + rootTreeNodeInorderIndex - inorderLeft, inorder, inorderLeft, rootTreeNodeInorderIndex, inorderIdxMap);

        //右子树
        rootTreeNode.right = reverseBuildTree(preorder, preorderLeft + 1 + rootTreeNodeInorderIndex - inorderLeft, preorderRight, inorder, rootTreeNodeInorderIndex + 1, inorderRight, inorderIdxMap);

        //清理当前层
        return rootTreeNode;
    }


    class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;

        TreeNode(int x) {
            val = x;
        }
    }

    public static void main(String[] args) {
        SolutionSevent solutionSevent = new SolutionSevent();
        int[] preorder = new int[]{3,9,20,15,7};
        int[] inorder = new int[]{9,3,15,20,7};
        solutionSevent.buildTree(preorder, inorder);
    }
}
