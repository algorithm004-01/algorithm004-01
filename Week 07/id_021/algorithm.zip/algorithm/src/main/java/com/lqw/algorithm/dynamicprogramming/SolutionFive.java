package com.lqw.algorithm.dynamicprogramming;

import java.util.Arrays;

/**
 * 最大子序列和 = 当前元素自身最大，或者当前元素加上之前后最大
 * 
 * 解题思路
 * 1、分治，重复子问题max_sum[i] = max(sub_max_sum[i-1] + nums[i], nums[i])
 * 2、状态数组 dp[i]
 * 3、dp方程 dp[i] = max(nums[i], dp[i-1] + nums[i])
 * 
 * @author linqiwen
 */
public class SolutionFive {

    public int maxSubArray(int[] nums) {

        int[] dp = Arrays.copyOf(nums, nums.length);

        int result = nums[0];

        for (int i = 1; i < nums.length; i++) {
            dp[i] = Math.max(nums[i], nums[i] + dp[i-1]);
            result = dp[i] > result ? dp[i] : result;
        }

        return result;

    }

}
